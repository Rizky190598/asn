<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
include 'db_kendaraan_asn';
?>

<?php
include 'db_kendaraan_asn';
$id = $_GET['id'];

if (isset($_POST['update'])) {
    $instansi = $_POST['instansi'];
    $jenis_roda = $_POST['jenis_roda'];
    $jumlah = $_POST['jumlah'];
    $asn_penanggung_jawab = $_POST['asn_penanggung_jawab'];

    $query = "UPDATE kendaraan SET
                instansi='$instansi',
                jenis_roda='$jenis_roda',
                jumlah='$jumlah',
                asn_penanggung_jawab='$asn_penanggung_jawab'
              WHERE id=$id";

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php");
    }
}

$query = "SELECT * FROM kendaraan WHERE id=$id";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Data Kendaraan</title>
</head>
<body>
    <h1>Edit Data Kendaraan</h1>
    <form method="POST" action="">
        <label>Instansi:</label><br>
        <input type="text" name="instansi" value="<?= $data['instansi'] ?>" required><br><br>

        <label>Jenis Roda:</label><br>
        <input type="text" name="jenis_roda" value="<?= $data['jenis_roda'] ?>" required><br><br>

        <label>Jumlah:</label><br>
        <input type="number" name="jumlah" value="<?= $data['jumlah'] ?>" required><br><br>

        <label>ASN Penanggung Jawab:</label><br>
        <input type="number" name="asn_penanggung_jawab" value="<?= $data['asn_penanggung_jawab'] ?>" required><br><br>

        <input type="submit" name="update" value="Update">
    </form>
</body>
</html>
