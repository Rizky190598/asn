<?php
include 'db.php';
$id = $_GET['id'];

$query = "DELETE FROM kendaraan WHERE id=$id";

if (mysqli_query($koneksi, $query)) {
    header("Location: index.php");
} else {
    echo "Error: " . mysqli_error($koneksi);
}
?>
