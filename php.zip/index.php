<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
include 'db_kendaraan_asn';
?>

<?php
include 'db_kendaraan_asn'; // Koneksi database
$query = "SELECT * FROM kendaraan";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Data Kendaraan ASN</title>
</head>
<body>
    <h1>Data Rekap Kendaraan</h1>
    <a href="tambah.php">Tambah Data</a>
    <table border="1" cellspacing="0" cellpadding="10">
        <tr>
            <th>No</th>
            <th>Instansi</th>
            <th>Jenis Roda</th>
            <th>Jumlah</th>
            <th>ASN Penanggung Jawab</th>
            <th>Aksi</th>
        </tr>
        <?php
        $no = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                <td>{$no}</td>
                <td>{$row['instansi']}</td>
                <td>{$row['jenis_roda']}</td>
                <td>{$row['jumlah']}</td>
                <td>{$row['asn_penanggung_jawab']}</td>
                <td>
                    <a href='edit.php?id={$row['id']}'>Edit</a> |
                    <a href='hapus.php?id={$row['id']}' onclick='return confirm(\"Hapus data ini?\")'>Hapus</a>
                </td>
            </tr>";
            $no++;
        }
        ?>
    </table>
</body>
</html>
