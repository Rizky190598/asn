<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
include 'db_kendaraan_asn';
?>

<?php
include 'db_kendaraan_asn';

if (isset($_POST['submit'])) {
    $instansi = $_POST['instansi'];
    $jenis_roda = $_POST['jenis_roda'];
    $jumlah = $_POST['jumlah'];
    $asn_penanggung_jawab = $_POST['asn_penanggung_jawab'];

    $query = "INSERT INTO kendaraan (instansi, jenis_roda, jumlah, asn_penanggung_jawab)
              VALUES ('$instansi', '$jenis_roda', '$jumlah', '$asn_penanggung_jawab')";
    
    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Tambah Data Kendaraan</title>
</head>
<body>
    <h1>Tambah Data Kendaraan</h1>
    <form method="POST" action="">
        <label>Instansi:</label><br>
        <input type="text" name="instansi" required><br><br>

        <label>Jenis Roda:</label><br>
        <input type="text" name="jenis_roda" required><br><br>

        <label>Jumlah:</label><br>
        <input type="number" name="jumlah" required><br><br>

        <label>ASN Penanggung Jawab:</label><br>
        <input type="number" name="asn_penanggung_jawab" required><br><br>

        <input type="submit" name="submit" value="Simpan">
    </form>
</body>
</html>
