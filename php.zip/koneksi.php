<?php
$host = "localhost";    // Nama host database (default: localhost)
$user = "root";         // Username MySQL (default: root di XAMPP)
$pass = "";             // Password MySQL (kosong jika default di XAMPP)
$db   = "db_kendaraan_asn";  // Nama database Anda

// Membuat koneksi ke database
$koneksi = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
} else {
    // echo "Koneksi berhasil!";
}
?>
