<?php 
	require 'koneksi.php';

	$nama = $_POST['nama'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$kelas = $_POST['kelas'];

	mysqli_query($conn,"INSERT INTO siswa VALUES('','$nama','$email','$password','$kelas')");

	header("location:index.php");
 ?>